# Moviebot
The chatbot lets you have general conversation with added added functionalities for movie details and movie recommendation.
You can query details for any movie with name and the bot shall give details {Title, Release date, Actors, Ratings, Plot}.
Also The user can ask the bot for recommending for any movie genre. 

Intent.py is our main project entry point. You need to set up Google DialogFlow account generate access tokens.
You need generate api acces token for OMDB.API

Clone the repository and install required python libraries as mentioned in the requirements.txt
The project uses the following
1. Python
2. Flask - webframework python
3. HTML
4. Bootstrap CSS
5. Javascript

